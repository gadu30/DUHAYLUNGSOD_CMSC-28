#include <iostream>
#include <string>
#include "yummy.h"

using namespace std;

int main(){
        sweet candy1("Nips", "Chocolate", "Rainbow");

        candy1.displayDetails();
        return 0;
}